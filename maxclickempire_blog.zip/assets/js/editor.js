document.getElementById('postForm').onsubmit = function(e) {
  e.preventDefault();
  alert("✅ Post will be generated (future integration for GitHub push).");
};